﻿namespace ParkingLot
{ 
    public enum SlotStatus
    {
        Empty,
        Booked
    }
}
