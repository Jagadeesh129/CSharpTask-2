﻿namespace ParkingLot
{
    public enum VehicleType
    {
        TwoWheeler,
        FourWheeler,
        HeavyVehicle
    }
}
