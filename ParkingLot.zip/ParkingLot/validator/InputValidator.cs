﻿namespace ParkingLot
{
    public class InputValidator
    {
        public int ReadInput(String str)
        {
            bool flag = true;
            int result = 0;

            while (flag)
            {
                flag = false;
                try
                {
                    Console.WriteLine(str);
                    result = Convert.ToInt32(Console.ReadLine());
                    if (result == -1)
                        Environment.Exit(0);
                }
                catch (Exception)
                {
                    Console.WriteLine(" ");
                    flag = true;
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Enter a proper number");
                    Console.ResetColor();
                    continue;
                }
                if (result < 0)
                {
                    Console.WriteLine(" ");
                    flag = true;
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Please Enter Positive number");
                    Console.ResetColor();
                }
            }

            Console.WriteLine(" ");
            return result;
        }
    }
}