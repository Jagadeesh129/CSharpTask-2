﻿namespace ParkingLot
{
    class Program
    {
        public static void Main()
        {
            ParkingLot parkingLots = new ParkingLot();
            parkingLots.CreateParkingLots();
            AdministratorService.ShowMainMenu();
        }
    }
}