﻿namespace ParkingLot
{
    public class Ticket
    {
        public int userid;
        public int id;
        public int slotNumber;
        public string vehicleNumber;
        public DateTime inTime;
        public DateTime outTime;
        public string status = "Opened";
        public int price;

        public Ticket(int userid, int id, int slotNumber, string vehicleNumber, DateTime inTime, DateTime outTime, int price)
        {
            this.userid = userid;
            this.id = id;
            this.slotNumber = slotNumber;
            this.vehicleNumber = vehicleNumber;
            this.inTime = inTime;
            this.outTime = outTime;
            this.price = price;
        }

        public void CloseTicket()
        {
            status = "Closed";
        }
    }
}
