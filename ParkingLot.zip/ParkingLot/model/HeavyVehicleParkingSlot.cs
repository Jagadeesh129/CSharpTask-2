﻿namespace ParkingLot
{
    public class HeavyVehicleParkingSlot : IParkingSlot
    {
        public int slotNumber { get; set; }
        public SlotStatus status { get; set; }
        public string name { get; set; }
        public int price { get; set; }

        public HeavyVehicleParkingSlot(int slotNumber, SlotStatus status, string name)
        {
            this.slotNumber = slotNumber;
            this.status = status;
            this.name = name;
            price = 5;
        }

        public void SetStatus(SlotStatus status)
        {
            this.status = status;
        }
    }
}
