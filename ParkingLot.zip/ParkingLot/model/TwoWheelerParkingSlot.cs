﻿namespace ParkingLot
{
    public class TwoWheelerParkingSlot : IParkingSlot
    {
        public int slotNumber { get; set; }
        public SlotStatus status { get; set; }
        public string name { get; set; }
        public int price { get; set; }

        public TwoWheelerParkingSlot(int slotNumber, SlotStatus status, string name)
        {
            this.slotNumber = slotNumber;
            this.status = status;
            this.name = name;
            price = 1;
        }

        public void SetStatus(SlotStatus status)
        {
            this.status = status;
        }
    }
}
