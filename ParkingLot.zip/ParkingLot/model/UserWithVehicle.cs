﻿namespace ParkingLot
{
    public class User
    {
        public int id;
        public string userName;
        public string userPhoneNumber;
        public string vehicleNumber;
        public string vehicleName;

        public User(int id, string userName, string userPhoneNumber, string vehicleNumber, string vehicleName)
        {
            this.id = id;
            this.userName = userName;
            this.userPhoneNumber = userPhoneNumber;
            this.vehicleNumber = vehicleNumber;
            this.vehicleName = vehicleName;
        }
    }
}
