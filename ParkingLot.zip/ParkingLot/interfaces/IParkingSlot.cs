﻿namespace ParkingLot
{
    public interface IParkingSlot
    {
        public int slotNumber { get; set; }
        public SlotStatus status { get; set; }
        public string name { get; set; }
        public int price { get; set; }
        public void SetStatus(SlotStatus status);
    }
}
