﻿#nullable disable
using ParkingLot.classes;

namespace ParkingLot
{
    public class AdministratorService
    {
        public static UserInputs userInputs = new UserInputs();
        public static List<IParkingSlot> slots = ParkingLot.GetSlots();

        public static void ShowMainMenu()
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"{1}.Park a Vehicle");
            Console.WriteLine($"{2}.UnPark a Vehicle");
            Console.ResetColor();
            int select = userInputs.ParkOrUnPark(2);
            switch (select)
            {
                case 1:
                    ParkVehicle();
                    break;
                case 2:
                    UnParkVehicle();
                    break;
            }
        }

        public static void ParkVehicle()
        {
            Console.ForegroundColor = ConsoleColor.Green;
            TypesOfSlots();
            Console.ResetColor();
            int option = userInputs.VehicleType();
            IParkingSlot slot = null;
            Console.WriteLine(((VehicleType)option-1).ToString());
            slot=CheckAvailability(((VehicleType)option-1).ToString());

            if (slot == null)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Parking is Not Available for Your Type Of Vehicle");
                Console.ResetColor();
                ShowMainMenu();
            }

            else
            {
                var userdetails = userInputs.EnterDetails();
                TicketService ticketObj = new TicketService();
                ticketObj.GenerateTicket(slot, userdetails);
                slot.SetStatus(SlotStatus.Booked);
                ShowMainMenu();
            }
        }

        public static IParkingSlot CheckAvailability(string name)
        {
            IParkingSlot slot = null;
            slot = slots.FirstOrDefault(slots =>
            {
                if (slots.name == name && slots.status == SlotStatus.Empty)
                {
                    return true;
                }
                return false;
            });
            if (slot != null)
                slot.SetStatus(SlotStatus.Booked);
            return slot;
        }

        public static void TypesOfSlots()
        {
            Console.WriteLine("1.Two Wheeler Parking");
            Console.WriteLine("2.Four Wheeler Parking");
            Console.WriteLine("3.Heavy Vehicle Parking");
        }

        public static void UnParkVehicle()
        {
            int ticketId = userInputs.ReadTicketId();
            int slotNumber = TicketService.CloseTicket(ticketId);
            if (slotNumber > 0)
            {
                IParkingSlot slot = null;
                slot = slots.First(slots =>
                {
                    if (slots.slotNumber == slotNumber)
                    {
                        return true;
                    }
                    return false;
                });
                slot.SetStatus(SlotStatus.Empty);
            }
            ShowMainMenu();
        }
    }
}