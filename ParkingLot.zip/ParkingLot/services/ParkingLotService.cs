﻿#nullable disable

namespace ParkingLot
{
    public class ParkingLot
    {
        private static List<IParkingSlot> slots = new List<IParkingSlot>();
        private  int counter = 1; 

        public void CreateParkingLots()
        {
            InputValidator validate = new InputValidator();
            Console.WriteLine("Enter -1 to Exit");
            int noOfTwoWheelerParkinglots = validate.ReadInput("Enter how many number of TwoWheeler Parking Lots");
            int noOfFourWheelerParkinglots = validate.ReadInput("Enter how many number of FourWheeler Parking Lots");
            int noOfHeavyVehicleParkinglots = validate.ReadInput("Enter how many number of Heavy Vehicle Parking Lots");
            CreateParkingslots<TwoWheelerParkingSlot>(noOfTwoWheelerParkinglots, VehicleType.TwoWheeler);
            CreateParkingslots<FourWheelerParkingSlot>(noOfFourWheelerParkinglots, VehicleType.FourWheeler);
            CreateParkingslots<HeavyVehicleParkingSlot>(noOfHeavyVehicleParkinglots, VehicleType.HeavyVehicle);
            if (noOfFourWheelerParkinglots == 0 && noOfHeavyVehicleParkinglots == 0 && noOfTwoWheelerParkinglots == 0)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("There are no Parking Slots are available");
                Environment.Exit(0);
                Console.ResetColor();
            }
        }

        public static List<IParkingSlot> GetSlots()
        {
            return slots;
        }

        public void CreateParkingslots<T>(int n, VehicleType name) where T : IParkingSlot
        {
            for (int i = 0; i < n; i++)
            {
                slots.Add((T)Activator.CreateInstance(typeof(T), new object[] { this.counter, SlotStatus.Empty, name.ToString() }));
                this.counter += 1;
            }
        }
    }
}