﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParkingLot.classes
{
    class TicketService
    {
        public UserInputs userInputs = new UserInputs();
        private static int ticketid = 1;
        private static List<Ticket> tickets = new List<Ticket>();
        public void GenerateTicket(IParkingSlot slot, User userdetails)
        {
            DateTime date = DateTime.Now;
            int minutes = this.userInputs.EnterTime();
            DateTime date2 = date.AddMinutes(minutes);
            int price = slot.price * minutes;
            var ticket = new Ticket(userdetails.id, ticketid, slot.slotNumber, userdetails.vehicleNumber, date, date2, price);
            tickets.Add(ticket);
            ticketid++;
            ShowTicket(ticket);
        }

        public void ShowTicket(Ticket ticket)
        {
            Console.ForegroundColor = ConsoleColor.DarkBlue;
            Console.WriteLine("Ticket Details are");
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("TicketNumber: {4}\nSlot Number: {0}\nVehicle Number: {1}\nIntime: {2}\nOutTime: {3} \nPrice: {5}\n", ticket.slotNumber, ticket.vehicleNumber, ticket.inTime, ticket.outTime, ticket.id, ticket.price);
            Console.ResetColor();
        }

        public static int CloseTicket(int ticketId) 
        {
            var ticket = tickets.Where(t=>t.id==ticketId && t.status== "Opened").ToList();
            if (ticket.Count()==0)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("No Such Ticket is Available");
                Console.ResetColor();
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.DarkMagenta;
                Console.WriteLine("Ticket Successfully Closed");
                Console.WriteLine("Unpark your Vehicle");
                ticket[0].status = "Closed";
                Console.ResetColor();
                return (ticket[0].slotNumber);
            }
            return -1;
        }
    }
}
