﻿#nullable disable

namespace ParkingLot
{
    public class UserInputs
    {
        private static InputValidator validate = new InputValidator();
        private int userid = 1;

        public int ParkOrUnPark(int limit)
        {
            int select = ReadInteger();
            if (select > 2 || select == 0)
            {
                return ParkOrUnPark(limit);
            }
            return select;
        }

        public int VehicleType()
        {
            int select = ReadInteger();
            if (select == 0 || select > 3)
            {
                return VehicleType();
            }

            return select;
        }

        public static int ReadInteger()
        {
            int select = validate.ReadInput("Please Enter Above Options Only");
            return select;
        }

        public User EnterDetails()
        {
            User userDetails;
            Console.WriteLine("Enter Your Name");
            string username = Console.ReadLine();
            ExitOrNot(username);
            Console.WriteLine("Enter Your Mobile Number");
            string mobileNumber = Console.ReadLine();
            ExitOrNot(mobileNumber);
            Console.WriteLine("Enter Vehicle Name");
            string vehicleName = Console.ReadLine();
            ExitOrNot(vehicleName);
            Console.WriteLine("Enter Vehicle Number");
            string vehicleNumber = Console.ReadLine();
            ExitOrNot(vehicleNumber);
            userDetails = new(this.userid, username, mobileNumber, vehicleName, vehicleNumber);
            this.userid += 1;
            return userDetails;
        }

        public static void ExitOrNot(String str)
        {
            try
            {
                if (Convert.ToInt32(str) == -1)
                {
                    Environment.Exit(0);
                }
            }
            catch { };
        }

        public int ReadTicketId()
        {
            int id = validate.ReadInput("Enter Your Ticket Number");
            return id;
        }

        public int EnterTime()
        {
            int minutes = validate.ReadInput("Enter number of minutes to Park a Vehicle");
            if (minutes == 0)
            {
                return EnterTime();
            }
            return minutes;
        }
    }
}
